package com.example.Ex02.Dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class BoardParam {

    private String boardCode;

    private int page = 1;
    private int limit = 5;
    private int offset = 0;

    private String whatColumn;
    private String keyword;

    public int getOffset() {
        return (page - 1) * limit;
    }
}