package com.example.Ex02.Dto;

import java.sql.Timestamp;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CommentsDto {
    private Long id;
    private Long userId;
    private String nickname;
    private Long postId;
    private Long parentId;

    @NotBlank(message = "댓글 내용을 입력해주세요.")
    private String content;

    private Timestamp createdAt;
    private Timestamp updatedAt;
    private String status;
}
