package com.example.Ex02.Dto;

import java.sql.Timestamp;
import java.util.List;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

@Getter @Setter
public class PostsDto {
    private Long id;
    private Long userId;
    private Long boardId;

    @NotBlank(message = "제목을 입력해주세요.")
    private String title;
    @NotBlank(message = "내용을 입력해주세요.")
    private String content;

    private int viewCount;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    private String nickname; //유저 닉네임
    private List<MultipartFile> files;

    private List<FilesDto> fileList;    // 첨부파일 목록
    private List<CommentsDto> comments; // 댓글 목록
    private List<Long> filesToDelete;
}
