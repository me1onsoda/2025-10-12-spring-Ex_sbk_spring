package com.example.Ex02.Dto;

import java.sql.Timestamp;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class MembersDto {
    // members 테이블의 모든 정보를 담는 DTO
    private Long id;

    @NotBlank(message = "id를 입력해주세요.")
    private String username;

    @NotBlank(message = "패스워드를 입력해주세요.")
    private String password;

    @NotBlank(message = "닉네임을 입력해주세요.")
    private String nickname;

    @NotEmpty(message = "성별을 선택해주세요..")
    private String gender;

    @NotEmpty(message = "연령대를 선택해주세요.")
    private String age;

    @NotBlank(message = "선호장르를 최소 하나 선택해주세요.")
    private String genre;

    private String status;
    private Timestamp createdAt;
    private Timestamp deletedAt;


}
