package com.example.Ex02.controller;

import com.example.Ex02.Dto.BoardParam;
import com.example.Ex02.Dto.CommentsDto;
import com.example.Ex02.Dto.MembersDto;
import com.example.Ex02.Dto.PostsDto;
import com.example.Ex02.service.CommentService;
import com.example.Ex02.service.PostService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CommentController {

    @Autowired
    private CommentService commentService;
    @Autowired
    private PostService postService;

    @PostMapping("/commentWrite")
    public String writeComment(@Valid @ModelAttribute("newComment") CommentsDto comment,
                               BindingResult bindingResult,
                               @ModelAttribute BoardParam boardParam,
                               HttpSession session, Model model) {

        MembersDto loginMember = (MembersDto) session.getAttribute("loginMember");
        if (loginMember == null) {
            String destination = "/postDetail?id=" + comment.getPostId();
            session.setAttribute("destination", destination);
            return "redirect:/loginForm";
        }

        if (bindingResult.hasErrors()) {
            PostsDto post = postService.getPostDetail(comment.getPostId());
            model.addAttribute("post", post);
            model.addAttribute("boardParam", boardParam);
            return "posts/detail";
        }

        comment.setUserId(loginMember.getId());
        commentService.saveComment(comment);
        return "redirect:/postDetail?id=" + comment.getPostId() + "&page=" + boardParam.getPage() + "&whatColumn=" + boardParam.getWhatColumn() + "&keyword=" + boardParam.getKeyword();
    }

    @PostMapping("/commentDelete")
    public String deleteComment(@RequestParam("id") Long commentId,
                                @RequestParam("postId") Long postId,
                                @ModelAttribute BoardParam boardParam,
                                HttpSession session) {

        MembersDto loginMember = (MembersDto) session.getAttribute("loginMember");
        CommentsDto comment = commentService.getCommentById(commentId);

        if (loginMember != null && comment.getUserId().equals(loginMember.getId())) {
            commentService.deleteComment(commentId);
        }
        return "redirect:/postDetail?id=" + postId + "&page=" + boardParam.getPage() + "&whatColumn=" + boardParam.getWhatColumn() + "&keyword=" + boardParam.getKeyword();
    }
}