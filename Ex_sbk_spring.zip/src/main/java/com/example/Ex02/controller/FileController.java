package com.example.Ex02.controller;

import com.example.Ex02.Dto.FilesDto;
import com.example.Ex02.service.FileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

@Controller
public class FileController {

    @Autowired
    private FileService fileService;

    @GetMapping("/files/download/{fileId}")
    public ResponseEntity<Resource> downloadFile(@PathVariable Long fileId) throws UnsupportedEncodingException {

        FilesDto fileInfo = fileService.getFileInfo(fileId);
        Resource resource = fileService.loadFileAsResource(fileInfo.getStoredFilepath());
        String originalFilename = URLEncoder.encode(fileInfo.getOriginalFilename(), "UTF-8");

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + originalFilename + "\"")
                .body(resource);
    }

    @GetMapping("/images/{fileId}")
    @ResponseBody
    public Resource showImage(@PathVariable Long fileId) {
        FilesDto fileInfo = fileService.getFileInfo(fileId);
        return fileService.loadFileAsResource(fileInfo.getStoredFilepath());
    }
}