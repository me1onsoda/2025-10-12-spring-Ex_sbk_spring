package com.example.Ex02.controller;

import com.example.Ex02.Dto.BoardParam;
import com.example.Ex02.Dto.BoardsDto;
import com.example.Ex02.service.BoardService;
import com.example.Ex02.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

@Controller
public class BoardController {

    @Autowired
    private BoardService boardService;
    @Autowired
    private PostService postService;

    @GetMapping("/")
    public String home(Model model) {
        List<BoardsDto> boardList = boardService.findAllBoards();
        model.addAttribute("boardList", boardList);
        return "home";
    }

    @GetMapping("/list")
    public String showPostList(@ModelAttribute BoardParam boardParam,
                               @RequestParam(value = "code", required = false) String code, Model model) {
        if ((boardParam.getBoardCode() == null || boardParam.getBoardCode().isBlank()) && code != null) {
            boardParam.setBoardCode(code);
        }// 요청파라미터명이 'code'로 왔으면 boardParam에 복사
        //boardParm에 code대신 boardCode로 작성후 진행해버려서 변환

        BoardsDto board = boardService.findByCode(boardParam.getBoardCode());
        Map<String, Object> result = postService.findPaginatedPosts(boardParam);

        model.addAttribute("board", board);
        model.addAttribute("postList", result.get("postList"));
        model.addAttribute("totalPage", result.get("totalPage"));

        model.addAttribute("boardParam", boardParam);
        System.out.println("boardCode = " + boardParam.getBoardCode());


        return "boards/list";
    }
}