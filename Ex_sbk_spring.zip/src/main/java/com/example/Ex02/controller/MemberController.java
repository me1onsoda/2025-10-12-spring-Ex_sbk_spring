package com.example.Ex02.controller;

import com.example.Ex02.Dto.MembersDto;
import com.example.Ex02.service.MemberService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

@Controller
public class MemberController {

    @Autowired
    private MemberService memberService;

    private static final String[] genreList = {
            "판타지", "로맨스", "현대판타지", "로맨스판타지", "무협",
            "대체역사", "라이트노벨", "스포츠", "SF"
    };

    @GetMapping("/memberList")
    public String memberList(Model model) {
        List<MembersDto> memberList = memberService.findAllMembers();
        model.addAttribute("memberList", memberList);
        return "members/memberList"; // "templates/members/memberList.html" 파일을 찾아감
    }

    @GetMapping("/registerForm")
    public String registerForm(Model model){
        model.addAttribute("member", new MembersDto());
        model.addAttribute("genreList", genreList);
        return "/members/registerForm";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("member") MembersDto member, BindingResult bindingResult){
        if(bindingResult.hasErrors()){
            return "/members/registerForm";
        }

        memberService.register(member);

        return "redirect:/";
    }

    @GetMapping("/checkUsername")
    @ResponseBody //이걸 쓰지않으면 자동으로 html이름을 찾아서 가버림, 이걸 써서 문자열 자체를 리턴하도록
    public String checkDuplicate(@RequestParam("username") String username){
        String result = "available";
        if(memberService.isUsernameExists(username)){
            result = "duplicate";
        }
        return result;
    }

    @GetMapping("/loginForm")
    public String loginForm(Model model){
        model.addAttribute("member", new MembersDto());
        return "/members/loginForm";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute MembersDto loginRequest, HttpServletResponse response,
                        HttpSession session, HttpServletRequest request) throws IOException {

        Map<String, Object> loginResult = memberService.login(loginRequest);
        String status = (String) loginResult.get("status");

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter pw = response.getWriter();


        if(status.equals("SUCCESS")){ //로그인 성공
            MembersDto loginMember = (MembersDto) loginResult.get("member");
            session.setAttribute("loginMember", loginMember);

            String destination = (String) session.getAttribute("destination");
            session.removeAttribute("destination");

            String url = (destination != null) ? destination : request.getContextPath() + "/";
            pw.println("<script>location.href='" + url + "';</script>");
        }
        else {
            //로그인 실패
            pw.println("<script>");
            if (status.equals("ID_NOT_FOUND")) {
                pw.println("alert('해당 아이디가 존재하지 않습니다.');");
            } else {
                pw.println("alert('비밀번호가 일치하지 않습니다.');");
            }
            pw.println("history.back();");
            pw.println("</script>");
        }


        return "home";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session){
        session.invalidate();
        return "redirect:/";
    }

    @GetMapping("/myPage")
    public String myPage(HttpSession session, Model model) {
        MembersDto loginMember = (MembersDto) session.getAttribute("loginMember");
        if (loginMember == null) {
            return "redirect:/loginForm";
        }
        model.addAttribute("memberInfo", loginMember);
        return "members/myPage";
    }

    @GetMapping("/editProfileForm")
    public String editProfileForm(HttpSession session, Model model) {
        MembersDto loginMember = (MembersDto) session.getAttribute("loginMember");
        if (loginMember == null) {
            return "redirect:/loginForm";
        }
        model.addAttribute("member", loginMember);
        model.addAttribute("genreList", genreList);
        return "members/editProfileForm";
    }

    @PostMapping("/editProfile")
    public String editProfile(@Valid @ModelAttribute("member") MembersDto member,
                              BindingResult bindingResult, Model model, HttpSession session) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("genreList", genreList);
            return "members/editProfileForm";
        }
        memberService.updateMember(member);
        // 세션 정보도 최신 정보로 업데이트
        session.setAttribute("loginMember", member);
        return "redirect:/myPage";
    }

    @PostMapping("/deleteAccount")
    public String deleteAccount(HttpSession session) {
        MembersDto loginMember = (MembersDto) session.getAttribute("loginMember");
        if (loginMember != null) {
            memberService.deleteMember(loginMember.getId());
            session.invalidate(); // 로그아웃
        }
        return "redirect:/";
    }
}
