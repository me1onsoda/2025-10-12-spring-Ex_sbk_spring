package com.example.Ex02.controller;

import com.example.Ex02.Dto.BoardParam;
import com.example.Ex02.Dto.CommentsDto;
import com.example.Ex02.Dto.MembersDto;
import com.example.Ex02.Dto.PostsDto;
import com.example.Ex02.service.PostService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.io.IOException;

@Controller
public class PostController {

    @Autowired
    private PostService postService;

    @GetMapping("/writeForm")
    public String writeForm(@RequestParam("boardId") Long boardId,Model model, HttpSession session){
        MembersDto loginMember = (MembersDto) session.getAttribute("loginMember");
        if (loginMember == null) {
            session.setAttribute("destination", "/writeForm?boardId=" + boardId);
            return "redirect:/loginForm";
        }
        PostsDto post = new PostsDto();
        post.setBoardId(boardId);
        model.addAttribute("post", post);
        return "posts/writeForm";
    }

    @PostMapping("/write")
    public String createPost(@Valid @ModelAttribute("post") PostsDto post, BindingResult bindingResult,
                             HttpSession session) throws IOException {
        if (bindingResult.hasErrors()) {
            return "posts/writeForm";
        }
        MembersDto loginMember = (MembersDto) session.getAttribute("loginMember");
        post.setUserId(loginMember.getId());
        Long newPostId = postService.savePost(post);
        return "redirect:/postDetail?id=" + newPostId;
    }

    @GetMapping("/postDetail")
    public String postDetail(@RequestParam("id") Long postId, @ModelAttribute BoardParam boardParam, Model model) {
        PostsDto postDetail = postService.getPostDetail(postId);
        if (postDetail == null) {
            return "redirect:/";
        }
        String boardCode = postService.findBoardCodeByPostId(postId);
        boardParam.setBoardCode(boardCode);
        model.addAttribute("post", postDetail);
        model.addAttribute("newComment", new CommentsDto());
        model.addAttribute("boardParam", boardParam);
        return "posts/detail";
    }

    @GetMapping("/posts/edit/{postId}")
    public String editForm(@PathVariable Long postId, Model model, HttpSession session) {
        PostsDto post = postService.getPostDetail(postId);
        MembersDto loginMember = (MembersDto) session.getAttribute("loginMember");
        if (loginMember == null || !post.getUserId().equals(loginMember.getId())) {
            return "redirect:/postDetail?id=" + postId;
        }
        model.addAttribute("post", post);
        return "posts/editForm";
    }

    @PostMapping("/posts/edit")
    public String updatePost(@Valid @ModelAttribute("post") PostsDto post,
                             BindingResult bindingResult, Model model) throws IOException {
        if (bindingResult.hasErrors()) {
            PostsDto originalPost = postService.findById(post.getId());
            post.setFileList(originalPost.getFileList());
            model.addAttribute("post", post);
            return "posts/editForm";
        }
        postService.updatePost(post);
        return "redirect:/postDetail?id=" + post.getId();
    }

    @PostMapping("/posts/delete")
    public String deletePost(@RequestParam("id") Long postId, HttpSession session) {
        PostsDto post = postService.getPostDetail(postId);
        MembersDto loginMember = (MembersDto) session.getAttribute("loginMember");
        if (loginMember != null && post.getUserId().equals(loginMember.getId())) {
            String boardCode = postService.findBoardCodeByPostId(postId);
            postService.deletePost(postId);
            return "redirect:/list?boardCode=" + boardCode;
        }
        return "redirect:/postDetail?id=" + postId;
    }
}