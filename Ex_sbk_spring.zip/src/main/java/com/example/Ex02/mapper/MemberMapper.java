package com.example.Ex02.mapper;

import com.example.Ex02.Dto.MembersDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MemberMapper {
    void insertMember(MembersDto member);
    int selectCountByUsername(String username);
    MembersDto findByUsername(String username);
    void updateMember(MembersDto member);
    void softDeleteMember(Long id);
    List<MembersDto> findAll();
}
