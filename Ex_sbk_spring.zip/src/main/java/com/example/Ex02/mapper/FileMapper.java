package com.example.Ex02.mapper;

import com.example.Ex02.Dto.FilesDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface FileMapper {
    void saveFile(FilesDto fileDto);
    List<FilesDto> findByPostId(Long postId);
    FilesDto findById(Long fileId);
    void deleteById(Long id);
}
