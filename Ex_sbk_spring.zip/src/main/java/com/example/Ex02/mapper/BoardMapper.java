package com.example.Ex02.mapper;

import com.example.Ex02.Dto.BoardsDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface BoardMapper {
    List<BoardsDto> findAll();

    BoardsDto findByCode(String code);
}
