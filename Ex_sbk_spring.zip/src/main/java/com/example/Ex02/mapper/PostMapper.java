package com.example.Ex02.mapper;

import com.example.Ex02.Dto.BoardParam;
import com.example.Ex02.Dto.PostsDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface PostMapper {
    List<PostsDto> findPaginatedByBoardCode(BoardParam boardParam);
    int countByBoardCode(BoardParam boardParam);
    String findBoardCodeByPostId(Long postId);
    PostsDto findById(Long postId);
    void savePost(PostsDto post);
    void updateViewCount(Long postId);
    void updatePost(PostsDto post);
    void deletePost(Long postId);
}
