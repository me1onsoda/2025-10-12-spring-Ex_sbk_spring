package com.example.Ex02.mapper;

import com.example.Ex02.Dto.CommentsDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CommentMapper {
    List<CommentsDto> findByPostId(Long postId);
    void saveComment(CommentsDto comment);
    CommentsDto findById(Long id);
    void deleteComment(Long id);
    int countReplies(Long parentId);
    void updateStatusToDelete(Long id);
}
