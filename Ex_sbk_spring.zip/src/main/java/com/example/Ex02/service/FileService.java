package com.example.Ex02.service;

import com.example.Ex02.Dto.FilesDto;
import com.example.Ex02.mapper.FileMapper;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;


@Service
public class FileService {

    public static final String UPLOAD_DIR = System.getProperty("user.dir") + "/uploads/";

    @Autowired
    private FileMapper fileMapper;

    @PostConstruct
    public void init() {
        try {
            Files.createDirectories(Paths.get(UPLOAD_DIR));
        } catch (IOException e) {
            throw new RuntimeException("폴더생성 오류");
        }
    }

    public void saveFile(MultipartFile multipartFile, Long postId) throws IOException {
        String originalFilename = multipartFile.getOriginalFilename();
        String storedFilename = UUID.randomUUID().toString() + "_" + originalFilename;

        File file = new File(UPLOAD_DIR + storedFilename);
        multipartFile.transferTo(file);

        FilesDto fileDto = new FilesDto();
        fileDto.setPostId(postId);
        fileDto.setOriginalFilename(originalFilename);
        fileDto.setStoredFilepath(storedFilename);
        fileDto.setFileSize(multipartFile.getSize());

        fileMapper.saveFile(fileDto);
    }

    public FilesDto getFileInfo(Long fileId) {
        return fileMapper.findById(fileId); // DB에서 파일 ID로 정보 가져오기
    }

    public Resource loadFileAsResource(String storedFilename) {
        try {
            Path filePath = Paths.get(UPLOAD_DIR).resolve(storedFilename).normalize();
            Resource resource = new UrlResource(filePath.toUri());
            if (resource.exists()) {
                return resource;
            } else {
                throw new RuntimeException("File not found " + storedFilename);
            }
        } catch (MalformedURLException ex) {
            throw new RuntimeException("File not found " + storedFilename, ex);
        }
    }

    public void deleteFile(String storedFilename) {
        File file = new File(UPLOAD_DIR + storedFilename);
        if (file.exists()) {
            file.delete();
        }
    }
}
