package com.example.Ex02.service;

import com.example.Ex02.Dto.MembersDto;
import com.example.Ex02.mapper.MemberMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MemberService {

    @Autowired
    private MemberMapper memberMapper;

    public void register(MembersDto member) {
        memberMapper.insertMember(member);
    }

    public boolean isUsernameExists(String username) {
        return memberMapper.selectCountByUsername(username) > 0;
    }

    public Map<String, Object> login(MembersDto loginRequest) {
        Map<String, Object> result = new HashMap<>();

        MembersDto memberDB = memberMapper.findByUsername(loginRequest.getUsername());

        if(memberDB == null){
            result.put("status", "ID_NOT_FOUND");
            return result;
        }

        if(!memberDB.getPassword().equals(loginRequest.getPassword())){
            result.put("status", "PASSWORD_MISMATCH");
            return result;
        }

        result.put("status", "SUCCESS");
        result.put("member", memberDB);
        return result;
    }

    public void updateMember(MembersDto member) {
        memberMapper.updateMember(member);
    }

    public void deleteMember(Long id) {
        memberMapper.softDeleteMember(id);
    }

    public List<MembersDto> findAllMembers() {
        return memberMapper.findAll();
    }
}
