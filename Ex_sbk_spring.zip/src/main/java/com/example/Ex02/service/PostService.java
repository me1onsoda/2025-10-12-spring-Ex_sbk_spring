package com.example.Ex02.service;

import com.example.Ex02.Dto.BoardParam;
import com.example.Ex02.Dto.CommentsDto;
import com.example.Ex02.Dto.FilesDto;
import com.example.Ex02.Dto.PostsDto;
import com.example.Ex02.mapper.CommentMapper;
import com.example.Ex02.mapper.FileMapper;
import com.example.Ex02.mapper.PostMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PostService {

    @Autowired
    private PostMapper postMapper;
    @Autowired
    private FileService fileService;
    @Autowired
    private FileMapper fileMapper;
    @Autowired
    private CommentMapper commentMapper;

    public Map<String, Object> findPaginatedPosts(BoardParam boardParam) {
        boardParam.setOffset(boardParam.getOffset());

        List<PostsDto> postList = postMapper.findPaginatedByBoardCode(boardParam);
        int totalCount = postMapper.countByBoardCode(boardParam);

        int totalPage = (int) Math.ceil((double) totalCount / boardParam.getLimit());

        Map<String, Object> result = new HashMap<>();
        result.put("postList", postList);
        result.put("totalPage", totalPage);

        return result;
    }

    public String findBoardCodeByPostId(Long postId) {
        return postMapper.findBoardCodeByPostId(postId);
    }

    public PostsDto findById(Long postId) {
        return postMapper.findById(postId);
    }

    @Transactional
    public Long savePost(PostsDto post) throws IOException {
        postMapper.savePost(post);
        if (post.getFiles() != null && !post.getFiles().isEmpty()) {
            for (MultipartFile file : post.getFiles()) {
                if (!file.isEmpty()) {
                    fileService.saveFile(file, post.getId());
                }
            }
        }
        return post.getId();
    }

    @Transactional(readOnly = true)
    public PostsDto getPostDetail(Long postId) {
        postMapper.updateViewCount(postId);
        PostsDto post = postMapper.findById(postId);
        if (post == null) {
            return null;
        }
        post.setFileList(fileMapper.findByPostId(postId));
        post.setComments(commentMapper.findByPostId(postId));
        return post;
    }


    @Transactional
    public void updatePost(PostsDto post) throws IOException {
        if (post.getFilesToDelete() != null && !post.getFilesToDelete().isEmpty()) {
            for (Long fileId : post.getFilesToDelete()) {
                FilesDto fileInfo = fileMapper.findById(fileId);
                if (fileInfo != null) {
                    fileService.deleteFile(fileInfo.getStoredFilepath());
                }
                fileMapper.deleteById(fileId);
            }
        }
        if (post.getFiles() != null && !post.getFiles().isEmpty()) {
            for (MultipartFile file : post.getFiles()) {
                if (!file.isEmpty()) {
                    fileService.saveFile(file, post.getId());
                }
            }
        }
        postMapper.updatePost(post);
    }

    @Transactional
    public void deletePost(Long postId) {
        List<FilesDto> filesToDelete = fileMapper.findByPostId(postId);
        postMapper.deletePost(postId);
        for (FilesDto file : filesToDelete) {
            fileService.deleteFile(file.getStoredFilepath());
        }
    }
}