package com.example.Ex02.service;

import com.example.Ex02.Dto.BoardsDto;
import com.example.Ex02.mapper.BoardMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BoardService {

    private final BoardMapper boardMapper;

    public BoardService(BoardMapper boardMapper) {
        this.boardMapper = boardMapper;
    }

    public List<BoardsDto> findAllBoards() {
        return boardMapper.findAll();
    }

    public BoardsDto findByCode(String code) {
        return boardMapper.findByCode(code);
    }
}
