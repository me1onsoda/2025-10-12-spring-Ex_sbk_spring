package com.example.Ex02.service;

import com.example.Ex02.Dto.CommentsDto;
import com.example.Ex02.mapper.CommentMapper;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommentService {

    @Autowired
    private CommentMapper commentMapper;

    public void saveComment(CommentsDto comment) {
        commentMapper.saveComment(comment);
    }

    public CommentsDto getCommentById(Long commentId) {
        return commentMapper.findById(commentId);
    }

    @Transactional
    public void deleteComment(Long commentId) {
        int replyCount = commentMapper.countReplies(commentId);

        if (replyCount > 0) {
            commentMapper.updateStatusToDelete(commentId);
        } else {
            commentMapper.deleteComment(commentId);
        }
    }
}