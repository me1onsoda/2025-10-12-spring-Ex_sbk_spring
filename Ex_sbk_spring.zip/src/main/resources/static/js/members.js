let idChecked = false; // 중복체크 버튼 클릭했는지 여부가 들어감
let idAvailable = false;

function checkId() {
    const idValue = document.getElementById('username').value;

    if (idValue === '') {
        alert("아이디를 입력해주세요");
        return;
    }

    fetch("/checkUsername?username=" + encodeURIComponent(idValue))
        .then(response => response.text())
        .then(result => {
            const msgSpan = document.getElementById('idCheckResult');
            idChecked = true;
            if (result == "duplicate") {
                msgSpan.textContent = "이미 사용중인 아이디입니다.";
                msgSpan.style.color = "red";
                idAvailable = false;
            } else {
                idAvailable = true;
                msgSpan.textContent = "사용 가능한 아이디입니다.";
                msgSpan.style.color = "green";
            }
        })
        .catch(error => {
            console.log("에러 발생 : " + error);
        });
}

function resetIdCheck() {
    idChecked = false;
    idAvailable = false;
    const msgSpan = document.getElementById('idCheckResult');

    msgSpan.textContent = "";
}

function validateForm() {
    if (!idChecked) {
        alert('아이디 중복체크를 해주세요.');
        return false;
    }
    if (!idAvailable) {
        alert('이미 사용중인 아이디입니다. 다른 아이디를 입력해주세요.');
        return false;
    }
    return true;
}